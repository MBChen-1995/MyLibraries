# How to set VS code sync

## create gist
https://blog.csdn.net/weixin_42060896/article/details/105007965

## create token
https://www.zhihu.com/search?type=content&q=VScode%20sync

## finished
